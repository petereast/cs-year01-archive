//Java
package Assignment;

import java.util.Scanner;

public class Exercise1{
	public static void main(String[] args) {
		System.out.println("[ce152-assignment] Exercise One");
		getValueOfPizza(getInput());
		
	}
	
	public static String getInput() {
		Scanner stdin = new Scanner(System.in);
		String out = stdin.nextLine();
		stdin.close();
		return out;
	}
	
	public static int getValueOfPizza(String input) {
		boolean large = (input.toCharArray()[0] == 'l');
		
		// Calculate base price
		int totalPrice = large ? 500: 400;
		
		int numberOfToppings = 0;
		
		String output = "";
				
		for(char attr: input.substring(1).toCharArray()) {
			//if (attr == 'l' || attr == 'm') {
				// Character already processed, ignore...
			//} else 
			if ( attr == 'h' ) {
				// Ham - £1.40 medium and £2.10 large
				totalPrice += large ? 210: 140;
				output += "ham, ";
			} else if ( attr == 'm' ) {
				// Mozzarella - £1.00 medium and £1.50 large
				totalPrice += large ? 150: 100;
				output += "mozzarella, ";
			} else if ( attr == 'o' ) {
				// Olives - £0.80 medium and £1.20 large
				totalPrice += large ? 120: 80;
				output += "olives, ";
			} else if ( attr == 'p' ) {
				// Pineapple - £1.00 medium and £1.50 large
				totalPrice += large ? 150: 100;
				output += "pineapple, ";
			} else if ( attr == 's' ) {
				// Spinach - £0.80 medium and £1.20 large
				totalPrice += large ? 120: 80;
				output += "spinach, ";
			}
			


		}
		System.out.println("Total price: "+(double)totalPrice/100);
		System.out.println(output);
		
		return totalPrice;
	}


}
